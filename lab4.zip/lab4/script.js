document.addEventListener('DOMContentLoaded', function() {
    
    const inputActivitate = document.getElementById('inputActivitate');
    const btnAdauga = document.getElementById('buton_add');
    const listaActivitati = document.getElementById('listaActivitati');

    const luni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];

    btnAdauga.addEventListener('click', function() {
        const textt = inputActivitate.value.trim();
        if (textt !== "") {
            
            const elementNou = document.createElement('li');
            const data = new Date();
			
            const zi = data.getDate();
            const lunaIndex = data.getMonth(); // 0-11
            const an = data.getFullYear();
            const luna = luni[lunaIndex];
			
            const textFinal = `${textt} -> adaugat la: ${zi} ${luna} ${an}`;
			
            elementNou.textContent =  textFinal; //li
			
            listaActivitati.appendChild(elementNou); // catre ul
			
            inputActivitate.value = ""; // golire
            
            

        }
    });
});