document.addEventListener('DOMContentLoaded', function() {
	
    const btnDetalii = document.getElementById('btnDetalii');
    const divDetalii = document.getElementById('detalii');
    const spanData = document.getElementById('dataProdus');

    const lunileAnului = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];
    divDetalii.classList.add('ascuns');

    const dataCurenta = new Date();
    const zi = dataCurenta.getDate();
    const lunaText = lunileAnului[dataCurenta.getMonth()];
    const an = dataCurenta.getFullYear();

    spanData.textContent = `${zi} ${lunaText} ${an}`;


    
    btnDetalii.addEventListener('click', function() {
        divDetalii.classList.toggle('ascuns');
        if (divDetalii.classList.contains('ascuns')) {
            btnDetalii.textContent = "Afiseaza detalii";
        } else {
            btnDetalii.textContent = "Ascunde detalii";
        }
		
    });
	
});